# -*- coding: utf-8 -*-
# ELK-specific data processing for BoltzTraP2

import numpy as np
from ase.units import Bohr, Hartree

def process_elk_eigenvalues(kpoints, eigenvalues):
    """Process ELK eigenvalues to BoltzTraP2 format.
    
    Args:
        kpoints: K-points in fractional coordinates
        eigenvalues: Band eigenvalues in Hartree
        
    Returns:
        tuple: (kpoints, ebands) in BoltzTraP2 format
    """
    # Convert kpoints to numpy array if not already
    kpoints = np.array(kpoints)
    eigenvalues = np.array(eigenvalues)
    
    # ELK typically outputs eigenvalues in Hartree
    # BoltzTraP2 works internally in Hartree, so no conversion needed
    
    # Ensure shape is (nbands, nkpoints)
    if eigenvalues.shape[0] < eigenvalues.shape[1]:
        eigenvalues = eigenvalues.T
    
    return kpoints, eigenvalues

def convert_elk_units(data, target='hartree'):
    """Convert ELK data units to target units.
    
    Args:
        data: Dictionary containing ELK data
        target: Target unit system ('hartree' or 'ev')
        
    Returns:
        dict: Data with converted units
    """
    converted = data.copy()
    
    if target.lower() == 'ev':
        # Convert from Hartree to eV
        converted['fermi'] *= Hartree
        converted['eigenvalues'] *= Hartree
        if 'pmatrix' in converted:
            converted['pmatrix'] *= Hartree * Bohr  # p = -iħ∇
    
    return converted

def parse_elk_bandstructure(elk_path):
    """Parse ELK bandstructure data from BAND.OUT.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Dictionary containing band structure data
    """
    # Implementation depends on ELK version
    # This would parse the band structure data from BAND.OUT
    # and return it in a format compatible with BoltzTraP2
    return {}

def validate_elk_data(data):
    """Validate ELK data for BoltzTraP2 compatibility.
    
    Args:
        data: Dictionary containing ELK data
        
    Returns:
        bool: True if data is valid
    """
    required_keys = ['kpoints', 'eigenvalues', 'fermi', 'nelect', 'atoms']
    for key in required_keys:
        if key not in data:
            raise ValueError(f"Missing required ELK data: {key}")
    
    if data['kpoints'].shape[0] != data['eigenvalues'].shape[1]:
        raise ValueError("Number of k-points doesn't match number of eigenvalues")
    
    return True

def extract_elk_symmetry(elk_path):
    """Extract symmetry information from ELK output.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Symmetry operations and k-point equivalences
    """
    # This would parse symmetry information from SYM.OUT or similar
    return {}
