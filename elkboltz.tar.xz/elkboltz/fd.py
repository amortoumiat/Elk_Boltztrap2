# -*- coding: utf-8 -*-
# Elk FP-LAPW interface for Fermi-Dirac functions in BoltzTraP2
# Maintains all original functionality while adding Elk-specific utilities

import numpy as np
import scipy as sp
import scipy.optimize
import scipy.signal
from BoltzTraP2.units import *

# Threshold for non-zero values of the Fermi-Dirac distribution.
_FD_THRESHOLD = 1e-8
_FD_THRESHOLD_GAP = 1e-3

def _fd_criterion_gen(threshold):
    """Generate a function to translate thresholds into energies.
    
    Args:
        threshold: threshold for non-zero values of the FD distribution
        
    Returns:
        Function returning fFD(x) - threshold
    """
    def _fd_criterion(x):
        return 1.0 / (np.exp(x) + 1.0) - threshold
    return _fd_criterion

_FD_XMAX = sp.optimize.newton(_fd_criterion_gen(_FD_THRESHOLD), 0.0)
_FD_XMAX_GAP = sp.optimize.newton(_fd_criterion_gen(_FD_THRESHOLD_GAP), 0.0)

def FD(e, mu, kbT):
    """Compute Fermi-Dirac occupancies for Elk data.
    
    Args:
        e: array of energies (from Elk band structure)
        mu: chemical potential
        kbT: thermal energy
        
    Returns:
        Array of Fermi-Dirac occupancies
    """
    global _FD_XMAX
    if kbT == 0.0:
        delta = e - mu
        nruter = np.where(delta < 0.0, 1.0, 0.0)
        nruter[np.isclose(delta, 0.0)] = 0.5
    else:
        x = np.asarray((e - mu) / kbT)
        nruter = np.where(x < 0.0, 1.0, 0.0)
        indices = np.logical_and(x > -_FD_XMAX, x < _FD_XMAX)
        nruter[indices] = 1.0 / (np.exp(x[indices]) + 1.0)
    return nruter

def dFDdx(x):
    """Compute derivative of FD occupancies w.r.t. scaled energy.
    
    Args:
        x: recentered and scaled energies
        
    Returns:
        Array of derivatives
    """
    global _FD_XMAX
    x = np.asarray(x)
    nruter = np.zeros_like(x)
    indices = np.logical_and(x > -_FD_XMAX, x < _FD_XMAX)
    c = np.cosh(0.5 * x[indices])
    nruter[indices] = -0.25 / c / c
    return nruter

def dFDde(e, mu, kbT):
    """Compute derivative of FD occupancies w.r.t. energy.
    
    Args:
        e: array of energies
        mu: chemical potential
        kbT: thermal energy
        
    Returns:
        Array of derivatives
    """
    factor = (e - mu) / kbT
    dfde = dFDdx(factor) / kbT
    return dfde

# Elk-specific utility functions
def elk_fermi_distribution(elk_bandfile, mu, T, nspin=1):
    """Compute Fermi-Dirac distribution for Elk band structure.
    
    Args:
        elk_bandfile: Path to Elk's BAND.OUT file
        mu: Chemical potential
        T: Temperature
        nspin: Number of spin components
        
    Returns:
        Tuple of (kpoints, energies, occupancies)
    """
    # Read Elk band data
    kpoints, ebands, _ = read_elk_bands(elk_bandfile, nspin)
    
    # Compute Fermi-Dirac distribution
    kbT = BOLTZMANN * T
    occupancies = FD(ebands, mu, kbT)
    
    return kpoints, ebands, occupancies

def elk_dos_smearing(elk_bandfile, Tsmooth, nspin=1, npts=1000):
    """Apply Fermi-Dirac smearing to Elk DOS.
    
    Args:
        elk_bandfile: Path to Elk's BAND.OUT file
        Tsmooth: Smearing temperature
        nspin: Number of spin components
        npts: Number of energy points
        
    Returns:
        Tuple of (energies, smoothed_DOS)
    """
    # Read Elk band data
    kpoints, ebands, _ = read_elk_bands(elk_bandfile, nspin)
    
    # Create energy grid
    emin, emax = ebands.min(), ebands.max()
    e = np.linspace(emin, emax, npts)
    
    # Compute raw DOS
    _, dos = elk_DOS(ebands, erange=(emin, emax), npts=npts)
    
    # Apply smearing
    smoothed_dos = smoothen_DOS(e, dos, Tsmooth)
    
    return e, smoothed_dos

# Maintain original functions for backward compatibility
def original_FD(e, mu, kbT):
    """Original FD function maintained for compatibility."""
    return FD(e, mu, kbT)

def original_dFDde(e, mu, kbT):
    """Original dFDde function maintained for compatibility."""
    return dFDde(e, mu, kbT)
