# -*- coding: utf-8 -*-
#    BoltzTraP2-ELK: SI Unit System for ELK FP-LAPW calculations
#    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
#    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]
#
#    This file is part of BoltzTraP2-ELK.
#
#    BoltzTraP2-ELK is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

import math
from ase.units import Bohr, Hartree, kJ, mol, _eps0, _mu0, _G, _k, _c, _hplanck

# Fundamental constants in SI units (CODATA 2018/2022)
BOLTZMANN_SI = _k                     # 1.380649e-23 J/K (exact, since 2019)
FINE_STRUCT = 1/137.035999084         # Fine structure constant (2018)
AVOGADRO = 6.02214076e23              # 1/mol (exact, since 2019)
Clight_SI = _c                        # 299792458 m/s (exact)
a0_SI = Bohr * 1e-10                  # 5.29177210903e-11 m (Bohr radius)
me_SI = 9.1093837015e-31              # kg (electron mass, 2018)
qe_SI = 1.602176634e-19               # C (elementary charge, exact since 2019)
hbar_SI = _hplanck                    # 1.054571817e-34 J·s (exact, since 2019)

# Atomic unit conversions (for ELK compatibility)
Ha_SI = Hartree * qe_SI               # 4.3597447222071e-18 J (Hartree energy)
Eh = Ha_SI                            # Hartree energy alias
Ry = 0.5 * Ha_SI                      # Rydberg energy (13.605693122994 eV)
au_to_kg = me_SI
au_to_m = a0_SI
au_to_s = hbar_SI / Eh
au_to_A = au_to_m * 1e10

# Base SI units (all = 1.0 in SI system)
Meter = 1.0                           # m
Kilogram = 1.0                        # kg
Second = 1.0                          # s
Coulomb = 1.0                         # C
Kelvin = 1.0                          # K

# Derived SI units
Newton = 1.0                          # kg·m/s²
Joule = 1.0                           # kg·m²/s²
Volt = 1.0                            # kg·m²/(A·s³)
Ampere = 1.0                          # C/s
Ohm = 1.0                             # kg·m²/(A²·s³)
Siemens = 1.0                         # A²·s³/(kg·m²)
Tesla = 1.0                           # kg/(A·s²)

# Common unit definitions
Angstrom = 1e-10                      # m
eV = qe_SI                            # 1.602176634e-19 J
BOLTZMANN = BOLTZMANN_SI              # J/K
Hartree_SI = Ha_SI                    # J

# ELK-specific unit conversions (atomic units to SI)
ELK_ENERGY_TO_SI = {
    'hartree': Ha_SI,
    'ha': Ha_SI,
    'ev': eV,
    'rydberg': Ry,
    'ry': Ry,
    'kjmol': (kJ/mol),
    'kcalmol': (4.184*kJ/mol)
}

ELK_LENGTH_TO_SI = {
    'bohr': a0_SI,
    'angstrom': Angstrom,
    'nm': 1e-9,
    'pm': 1e-12
}

def convert_to_SI(value, from_unit):
    """Convert value from specified unit to SI base units.
    
    Args:
        value: Value to convert
        from_unit: Source unit (see ELK_*_TO_SI dictionaries)
        
    Returns:
        Value in SI units
    """
    if from_unit.lower() in ELK_ENERGY_TO_SI:
        return value * ELK_ENERGY_TO_SI[from_unit.lower()]
    elif from_unit.lower() in ELK_LENGTH_TO_SI:
        return value * ELK_LENGTH_TO_SI[from_unit.lower()]
    else:
        raise ValueError(f"Unsupported unit: {from_unit}")

def convert_from_SI(value, to_unit):
    """Convert value from SI base units to specified unit.
    
    Args:
        value: Value in SI units
        to_unit: Target unit (see ELK_*_TO_SI dictionaries)
        
    Returns:
        Value in target units
    """
    if to_unit.lower() in ELK_ENERGY_TO_SI:
        return value / ELK_ENERGY_TO_SI[to_unit.lower()]
    elif to_unit.lower() in ELK_LENGTH_TO_SI:
        return value / ELK_LENGTH_TO_SI[to_unit.lower()]
    else:
        raise ValueError(f"Unsupported unit: {to_unit}")

def convert_units(value, from_unit, to_unit):
    """Convert between any supported units.
    
    Args:
        value: Value to convert
        from_unit: Source unit
        to_unit: Target unit
        
    Returns:
        Converted value
    """
    si_value = convert_to_SI(value, from_unit)
    return convert_from_SI(si_value, to_unit)

def si_units_info():
    """Print information about the SI unit system and conversions."""
    print("SI Unit System Information")
    print("=========================")
    print("Base Units:")
    print(f"  1 meter = {Meter} m")
    print(f"  1 kilogram = {Kilogram} kg")
    print(f"  1 second = {Second} s")
    print(f"  1 ampere = {Ampere} A")
    print(f"  1 kelvin = {Kelvin} K")
    print("\nDerived Units:")
    print(f"  1 newton = {Newton} kg·m/s²")
    print(f"  1 joule = {Joule} kg·m²/s²")
    print(f"  1 volt = {Volt} kg·m²/(A·s³)")
    print(f"  1 ohm = {Ohm} kg·m²/(A²·s³)")
    print("\nCommon Conversions:")
    print(f"  1 Hartree = {Ha_SI} J = {convert_units(1, 'hartree', 'ev')} eV")
    print(f"  1 Bohr = {a0_SI} m = {convert_units(1, 'bohr', 'angstrom')} Å")
    print("\nSupported Energy Units:", list(ELK_ENERGY_TO_SI.keys()))
    print("Supported Length Units:", list(ELK_LENGTH_TO_SI.keys()))

# Maintain atomic units for backward compatibility
# (These now represent conversion factors to SI)
Clight = Clight_SI / (a0_SI * Eh/hbar_SI)  # Speed of light in atomic units
EPSILON0 = _eps0  # Vacuum permittivity in SI (8.8541878128e-12 F/m)
MU0 = _mu0        # Vacuum permeability in SI (4πe-7 N/A²)
MUB = 9.2740100783e-24  # Bohr magneton in J/T (2018)

# Backward compatibility aliases
Ha = Ha_SI
au_to_kg = me_SI
au_to_m = a0_SI
au_to_s = hbar_SI / Eh
