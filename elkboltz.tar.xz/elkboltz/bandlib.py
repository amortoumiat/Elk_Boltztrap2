# -*- coding: utf-8 -*-
# Elk FP-LAPW interface for BoltzTraP2
# This version is adapted to process Elk band structure data

import numpy as np
import scipy as sp
import scipy.integrate
import scipy.optimize
import scipy.signal
from BoltzTraP2.fd import *
from BoltzTraP2.fd import _FD_XMAX, _FD_XMAX_GAP
from BoltzTraP2.units import *

def read_elk_bands(elk_bandfile, nspin=1):
    """Read band structure data from Elk output files.
    
    Args:
        elk_bandfile: Path to Elk's BAND.OUT file
        nspin: Number of spin components (1 for non-spin-polarized, 2 for spin-polarized)
        
    Returns:
        Tuple containing:
        - k-points (nkpoints, 3) array
        - Band energies (nbands, nkpoints) array
        - Band velocities (nbands, 3, nkpoints) array if available
    """
    data = np.loadtxt(elk_bandfile)
    nkpoints = int(data[-1, 0]) + 1
    nbands = int(data[-1, 1]) + 1
    
    # Reshape the data
    data = data.reshape(nkpoints, nbands, -1)
    
    # Extract k-points (first three columns)
    kpoints = data[:, 0, 1:4]
    
    # Extract band energies
    ebands = data[:, :, 4].T
    
    # Check if velocities are present (columns 5-7)
    if data.shape[2] >= 7:
        velocities = np.zeros((nbands, 3, nkpoints))
        for i in range(3):
            velocities[:, i, :] = data[:, :, 5+i].T
    else:
        velocities = None
    
    return kpoints, ebands, velocities

def elk_DOS(eband, erange=None, npts=None, weights=None, Tmin=None):
    """Compute the density of states from Elk band data.
    
    Modified version of DOS() that handles Elk's band structure format.
    
    Args:
        eband: (nbands, nkpoints) array with the band energies
        erange: Energy range tuple (min, max). If None, uses min/max of bands.
        npts: Number of bins. If None, uses _suggest_nbins.
        weights: Optional weights array (same shape as eband)
        Tmin: Minimum temperature for bin suggestion.
        
    Returns:
        Tuple of (bin_energies, DOS)
    """
    if erange is None:
        erange = (eband.min(), eband.max())
    if npts is None:
        npts = _suggest_nbins(eband, erange, Tmin)
    
    hist, bin_edges = np.histogram(eband, bins=npts, range=erange, weights=weights)
    bin_centers = 0.5 * (bin_edges[:-1] + bin_edges[1:])
    
    # Normalize DOS by k-point count and energy bin width
    nkpoints = eband.shape[1]
    delta_e = (erange[1] - erange[0]) / npts
    dos = hist / (nkpoints * delta_e)
    
    return bin_centers, dos

def elk_BTPDOS(eband, vvband=None, cband=None, erange=None, npts=None, 
               scattering_model="uniform_tau", Tmin=None):
    """Compute DOS and transport properties from Elk data.
    
    Modified version of BTPDOS() for Elk's band structure format.
    
    Args:
        eband: (nbands, nkpoints) array with band energies
        vvband: (nbands, 3, 3, nkpoints) array with velocity outer products
        cband: Optional curvature data
        erange: Energy range tuple
        npts: Number of bins
        scattering_model: Scattering model choice
        Tmin: Minimum temperature
        
    Returns:
        Tuple of (energies, DOS, transport_DOS, curvature_DOS)
    """
    # Compute regular DOS
    e, dos = elk_DOS(eband, erange=erange, npts=npts, Tmin=Tmin)
    npts = e.size
    
    # Initialize transport DOS if velocities are available
    if vvband is not None:
        vvdos = np.zeros((3, 3, npts))
        multpl = np.ones_like(eband)
        
        # Handle different scattering models
        if isinstance(scattering_model, str):
            if scattering_model == "uniform_lambda":
                multpl = lambda_to_tau(vvband, multpl)
            elif scattering_model != "uniform_tau":
                raise ValueError("Unknown scattering model")
        elif isinstance(scattering_model, np.ndarray):
            if scattering_model.shape != eband.shape:
                raise ValueError("Scattering model shape mismatch")
            multpl = scattering_model
        else:
            raise ValueError("Invalid scattering model")
        
        # Compute transport DOS components
        for i in range(3):
            for j in range(i, 3):  # Only compute upper triangle
                weights = vvband[:, i, j, :] * multpl
                _, vvdos[i, j] = elk_DOS(eband, weights=weights.T, 
                                        erange=erange, npts=npts)
                if i != j:  # Symmetrize
                    vvdos[j, i] = vvdos[i, j]
    else:
        vvdos = None
    
    # Compute curvature DOS if available
    if cband is not None and vvband is not None:
        cdos = np.zeros((3, 3, 3, npts))
        for i in range(3):
            for j in range(3):
                for k in range(3):
                    weights = cband[:, i, j, k, :] * multpl * multpl
                    _, cdos[i, j, k] = elk_DOS(eband, weights=weights.T, 
                                              erange=erange, npts=npts)
    else:
        cdos = None
    
    return e, dos, vvdos, cdos

# The rest of the original functions can be used as-is since they operate on 
# DOS data rather than raw band structure data. The main changes are in the
# data loading and initial processing functions.

def elk_calc_transport(elk_bandfile, N0, Tr, vuc, nspin=1, 
                      scattering_model="uniform_tau", Tmin=None):
    """Complete transport calculation pipeline for Elk data.
    
    Args:
        elk_bandfile: Path to Elk's BAND.OUT file
        N0: Number of valence electrons
        Tr: Array of temperatures to evaluate
        vuc: Unit cell volume
        nspin: Number of spin components
        scattering_model: Scattering model choice
        Tmin: Minimum temperature
        
    Returns:
        Dictionary containing transport coefficients
    """
    # Read Elk data
    kpoints, ebands, velocities = read_elk_bands(elk_bandfile, nspin)
    
    # Compute velocity outer products if available
    if velocities is not None:
        nbands, _, nkpoints = velocities.shape
        vvband = np.zeros((nbands, 3, 3, nkpoints))
        for i in range(3):
            for j in range(3):
                vvband[:, i, j, :] = velocities[:, i, :] * velocities[:, j, :]
    else:
        vvband = None
    
    # Compute DOS and transport properties
    e, dos, vvdos, _ = elk_BTPDOS(ebands, vvband, None, None, None, 
                                 scattering_model, Tmin)
    
    # Find chemical potential range
    mur = np.linspace(e.min(), e.max(), 100)
    
    # Compute Fermi integrals
    N, L0, L1, L2, _ = fermiintegrals(e, dos, vvdos, mur, Tr)
    
    # Compute Onsager coefficients
    sigma, seebeck, kappa, _ = calc_Onsager_coefficients(L0, L1, L2, mur, Tr, vuc)
    
    return {
        'energies': e,
        'dos': dos,
        'chemical_potentials': mur,
        'temperatures': Tr,
        'conductivity': sigma,
        'seebeck': seebeck,
        'thermal_conductivity': kappa
    }
