# -*- coding: utf-8 -*-
# ELK FP-LAPW DFT Module for Transport Calculations
# Handles reading ELK output and processing DFT data

import os
import glob
import logging
import math
import collections
import functools
import numpy as np

import ase
import ase.io
from ase.units import Bohr, Ha, eV, Angstrom

class LoaderError(Exception):
    """Generic exception class for problems in loaders."""

# List of format loaders
loaders = []

def register_loader(name, loader):
    """Add a loader to the list of registered loaders."""
    loaders.append((name, loader))

class ELKLoader:
    """Loader for ELK FP-LAPW calculations."""
    
    def __init__(self, directory):
        if not isinstance(directory, str):
            raise LoaderError("This loader only works with directories")
        
        # Find and parse ELK output files
        elk_data = self._parse_elk_directory(directory)
        
        # Set required attributes
        self.sysname = elk_data['sysname']
        self.atoms = elk_data['atoms']
        self.dosweight = elk_data['dosweight']
        self.kpoints = elk_data['kpoints']
        self.fermi = elk_data['fermi']
        self.ebands = elk_data['ebands']
        self.nelect = elk_data['nelect']
        
        # Optional attributes
        self.magmom = elk_data.get('magmom')
        self.mommat = elk_data.get('mommat')
    
    def _parse_elk_directory(self, directory):
        """Parse ELK output files in directory."""
        from .io import read_elk_output  # Import local IO module
        
        data = read_elk_output(directory)
        
        # Process band structure
        nspin = data['ebands'].shape[0]
        ebands = data['ebands'].transpose((0, 2, 1))  # (nspin, nbands, nk)
        
        # Determine DOS weight
        if nspin > 1 or (data.get('magmom') is not None and 
                         data['magmom'].ndim > 1):
            dosweight = 1.0  # Spin-polarized
        else:
            dosweight = 2.0  # Non-spin-polarized
            
        # Flatten bands along spin axis
        ebands = ebands.reshape((-1, ebands.shape[-1]))
        
        return {
            'sysname': data.get('sysname', os.path.basename(directory)),
            'atoms': data['atoms'],
            'dosweight': dosweight,
            'kpoints': data['kpoints'],
            'fermi': data['fermi'],
            'ebands': ebands,
            'nelect': data['nelect'],
            'magmom': data.get('magmom'),
            'mommat': data.get('mommat')
        }

register_loader("ELK", ELKLoader)

class ELKData:
    """Objects of this class hold structural and electronic information from ELK."""
    
    def __init__(self, directory, derivatives=False, *args, **kwargs):
        """Create an ELKData object from a directory."""
        # Try all registered loaders
        for label, loader in loaders[::-1]:
            logging.info(f"Looking for a {label} calculation")
            try:
                loaded = loader(directory, *args, **kwargs)
            except LoaderError as e:
                logging.info(f"Error in {label} loader: {e}")
                continue
                
            self.source = label
            break
        else:
            raise ValueError(f"No calculation found in directory {directory}")
            
        logging.info(f"Successfully loaded a {self.source} calculation")
        
        # Copy required attributes
        self.sysname = loaded.sysname
        self.atoms = loaded.atoms
        self.dosweight = loaded.dosweight
        self.kpoints = loaded.kpoints
        self.fermi = loaded.fermi
        self.ebands = loaded.ebands
        self.nelect = loaded.nelect
        
        # Handle derivatives (momentum matrix elements)
        if derivatives:
            if hasattr(loaded, 'mommat'):
                self.mommat = loaded.mommat
            else:
                raise ValueError(
                    f"No derivative information found in directory {directory}")
        else:
            self.mommat = None
            if hasattr(loaded, 'mommat'):
                logging.info("Derivative information will be discarded")
                
        # Handle magnetic moments
        self.magmom = getattr(loaded, 'magmom', None)
        if self.magmom is None:
            logging.info("Assuming a non-spin-polarized calculation")
            
        logging.info(f"Fermi energy: {self.fermi}")
        
    def bandana(self, emin=-np.inf, emax=np.inf):
        """Filter bands outside an energy window."""
        bandmin = np.min(self.ebands, axis=1)
        bandmax = np.max(self.ebands, axis=1)
        
        ntoolow = np.count_nonzero(bandmax <= emin)
        accepted = np.logical_and(bandmin < emax, bandmax > emin)
        
        logging.info("BANDANA output")
        for iband in range(len(self.ebands)):
            logging.info(
                f"{iband} {bandmin[iband]} {bandmax[iband]} {accepted[iband]}")
                
        self.ebands = self.ebands[accepted]
        if self.mommat is not None:
            self.mommat = self.mommat[:, accepted, :]
            
        # Adjust electron count for removed bands
        self.nelect -= self.dosweight * ntoolow
        return accepted
        
    def get_lattvec(self):
        """Get lattice vectors in Bohr."""
        if not hasattr(self, 'lattvec'):
            self.lattvec = self.atoms.get_cell().T * Angstrom / Bohr
        return self.lattvec
        
    def get_volume(self):
        """Get unit cell volume in Bohr^3."""
        if not hasattr(self, 'UCvol'):
            lattvec = self.get_lattvec()
            self.UCvol = np.abs(np.linalg.det(lattvec))
        return self.UCvol
        
    def get_formula_count(self):
        """Return number of formula units in cell."""
        counts = collections.Counter(self.atoms.get_chemical_symbols())
        return functools.reduce(math.gcd, counts.values())

# Register the ELK loader (will be tried first)
register_loader("ELK", ELKLoader)
