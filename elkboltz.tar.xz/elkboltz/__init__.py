# -*- coding: utf-8 -*-
#    BoltzTraP2-ELK: An extension for ELK FP-LAPW interoperability
#    Program for interpolating band structures and calculating
#    semi-classical transport coefficients from ELK FP-LAPW calculations.
#
#    Original BoltzTraP2 Copyright (C) 2017-2025:
#        Georg K. H. Madsen <georg.madsen@tuwien.ac.at>
#        Jesús Carrete <jesus.carrete.montana@tuwien.ac.at>
#        Matthieu J. Verstraete <matthieu.verstraete@ulg.ac.be>
#        Genadi Naydenov <gan503@york.ac.uk>
#
#    ELK-specific modifications Copyright (C) [YEAR] [YOUR NAME/INSTITUTION]
#
#    This file is part of BoltzTraP2-ELK.
#
#    BoltzTraP2-ELK is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    BoltzTraP2-ELK is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with BoltzTraP2-ELK.  If not, see <http://www.gnu.org/licenses/>.

# Define the list of submodules that will be imported by
# from BoltzTraP2 import *
__all__ = ["bandlib", "dft", "fite", "io", "elklib", "elkio"]

# ELK-specific module imports
from .elklib import (
    read_elk_bands,
    parse_elk_kpoints,
    process_elk_eigenvals,
    extract_elk_pmatrix
)

from .elkio import (
    load_elk_output,
    save_elk_bt2_data,
    convert_elk_to_hdf5
)
