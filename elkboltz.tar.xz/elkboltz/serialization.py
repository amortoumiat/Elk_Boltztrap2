# -*- coding: utf-8 -*-
#    BoltzTraP2-ELK: Serialization for ELK FP-LAPW calculations
#    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
#    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]

import copy
import datetime
import json
import lzma
import numpy as np
import ase
from BoltzTraP2.misc import warning, elk_info
from BoltzTraP2.version import *
from BoltzTraP2.elkio import get_elk_metadata  # ELK-specific metadata reader

# ELK-specific constants
ELK_FORMAT_VERSION = "1.0"
ELK_METADATA_KEYS = ['elk_version', 'input_parameters', 'kpoint_grid']

class ELKDataEncoder(json.JSONEncoder):
    """Extended JSON encoder for ELK-specific data types."""
    
    def default(self, o):
        """Handle ELK-specific data types in addition to base types."""
        # First try parent class handling
        try:
            return super().default(o)
        except TypeError:
            pass
            
        # ELK-specific type handling
        if isinstance(o, ELKBandStructure):
            return {
                'BoltzTraP2_type': 'ELKBandStructure',
                'kpoints': o.kpoints,
                'eigenvalues': o.eigenvalues,
                'fermi': o.fermi
            }
        return json.JSONEncoder.default(self, o)

def elk_object_hook(d):
    """Extended object hook for ELK-specific types."""
    if 'BoltzTraP2_type' in d:
        if d['BoltzTraP2_type'] == 'ELKBandStructure':
            return ELKBandStructure(
                kpoints=np.array(d['kpoints']),
                eigenvalues=np.array(d['eigenvalues']),
                fermi=d['fermi']
            )
    return object_hook(d)  # Fall back to original hook

def save_elk_calculation(filename, data, equivalences, coeffs, elk_metadata=None):
    """Save ELK calculation data with enhanced metadata.
    
    Args:
        filename: Output file path
        data: DFTData object (ELK-specific)
        equivalences: k-point equivalences
        coeffs: Interpolation coefficients
        elk_metadata: Additional ELK-specific metadata
    """
    metadata = gen_bt2_metadata(data, derivatives=data.mommat is not None)
    
    # Add ELK-specific metadata
    if elk_metadata is None:
        elk_metadata = get_elk_metadata(data.source)
    metadata.update({
        'elk_metadata': elk_metadata,
        'format_version': ELK_FORMAT_VERSION
    })
    
    with lzma.open(filename, "wt", encoding="utf-8", preset=0) as f:
        json.dump([data, equivalences, coeffs, metadata], f, cls=ELKDataEncoder)

def load_elk_calculation(filename):
    """Load ELK calculation data with metadata validation."""
    data, equivalences, coeffs, metadata = load_calculation(filename)
    
    # Validate ELK-specific data
    if 'elk_metadata' not in metadata:
        warning("Loaded file is missing ELK metadata - may not be ELK calculation")
    
    # Convert k-points to ELK format if needed
    if metadata.get('source', '').lower() == 'elk':
        equivalences = [convert_to_elk_kpoints(k) for k in equivalences]
    
    return data, equivalences, coeffs, metadata

def gen_elk_metadata(data):
    """Generate ELK-specific metadata dictionary."""
    return {
        'elk_version': data.elk_metadata.get('version', 'unknown'),
        'input_parameters': data.elk_metadata.get('parameters', {}),
        'kpoint_grid': get_kpoint_grid(data.kpoints),
        'calculation_time': datetime.datetime.now().isoformat()
    }

# Keep original functions with ELK-aware modifications
save_calculation = save_elk_calculation
load_calculation = load_elk_calculation

# Original functions remain unchanged but are now ELK-aware
# [Rest of the original functions...]
