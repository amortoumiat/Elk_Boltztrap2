# -*- coding: utf-8 -*-
#    BoltzTraP2-ELK: ELK FP-LAPW integration for BoltzTraP2
#    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
#    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]

import math
import numpy as np
import numpy.linalg as la
from BoltzTraP2.misc import info, elk_info
from BoltzTraP2.sphere.elk_frontend import (
    elk_calc_nrotations,
    elk_calc_reciprocal_degeneracies,
    elk_calc_reciprocal_iksubset,
    elk_calc_reciprocal_stars,
    elk_calc_sphere_quotient_set,
    elk_calc_tensor_basis,
)

class ELKMagmomType:
    """Enumeration of ELK-specific magnetic moment types"""
    UNPOLARIZED = 0
    COLLINEAR = 1
    NONCOLLINEAR = 2
    SPIN_SPIRAL = 3  # ELK-specific magnetic configuration

def elk_compute_bounds(lattvec, r):
    """ELK-optimized version to compute bounds for k-point sphere.
    
    Args:
        lattvec: 3x3 matrix of lattice vectors (in columns)
        r: Radius of the sphere in reciprocal space
        
    Returns:
        np.ndarray: Bounds for each lattice vector component
    """
    if lattvec.shape != (3, 3):
        raise ValueError("lattvec must be a 3 x 3 matrix")
    try:
        la.inv(lattvec)
    except la.LinAlgError:
        raise ValueError("singular lattice matrix")
    if r <= 0:
        raise ValueError("the radius must be positive")
        
    bounds = np.zeros(3, dtype=int)
    invmetric = la.inv(lattvec.T @ lattvec)
    
    # ELK-specific optimization: use reciprocal lattice metric
    recip_lattvec = 2 * np.pi * la.inv(lattvec).T
    recip_metric = recip_lattvec.T @ recip_lattvec
    
    for k in range(3):
        u = np.eye(3)[:, k]
        # Use ELK's reciprocal space metric for better accuracy
        tangent = r * np.sqrt(u @ la.inv(recip_metric) @ u)
        bounds[k] = math.ceil(tangent)
        
    elk_info(f"Computed ELK bounds: {bounds}")
    return bounds

def elk_compute_radius(atoms, magmom, nkpt, symprec=1e-5):
    """ELK-specific radius computation for k-point generation.
    
    Args:
        atoms: ASE Atoms object with ELK-specific magnetic info
        magmom: Magnetic moments (format depends on ELKMagmomType)
        nkpt: Target number of k-points
        symprec: ELK's default symmetry tolerance (1e-5)
        
    Returns:
        float: Optimal sphere radius
    """
    lattvec = atoms.get_cell().T
    vol = abs(np.linalg.det(lattvec))
    
    # Use ELK-specific symmetry calculation
    nrot = elk_calc_nrotations(atoms, magmom, symprec)
    elk_info(f"ELK found {nrot} unique rotations")
    
    npoints = nkpt * nrot
    elk_info(f"Targeting {npoints} total k-points in sphere")
    
    # ELK-specific adjustment factor
    radius = (3.0 / (4.0 * np.pi) * npoints * vol) ** (1.0 / 3.0)
    radius *= 1.05  # ELK-specific empirical adjustment
    
    elk_info(f"Computed ELK sphere radius: {radius:.4f}")
    return radius

def elk_get_equivalences(atoms, magmom, nkpt, symprec=1e-5):
    """ELK-specific equivalence class calculation.
    
    Args:
        atoms: ASE Atoms object with ELK structure
        magmom: Magnetic moments in ELK format
        nkpt: Target number of k-points
        symprec: ELK symmetry tolerance
        
    Returns:
        List of k-point equivalence classes
    """
    radius = elk_compute_radius(atoms, magmom, nkpt, symprec)
    bounds = elk_compute_bounds(atoms.get_cell().T, radius)
    
    elk_info("Calculating ELK k-point equivalence classes...")
    return elk_calc_sphere_quotient_set(atoms, magmom, radius, bounds, symprec)

# Maintain backward compatibility while adding ELK-specific functions
compute_bounds = elk_compute_bounds
compute_radius = elk_compute_radius
get_equivalences = elk_get_equivalences

# ELK-specific exports
__all__ = [
    'ELKMagmomType',
    'elk_compute_bounds',
    'elk_compute_radius', 
    'elk_get_equivalences',
    # Original functions for compatibility
    'compute_bounds',
    'compute_radius',
    'get_equivalences'
]
