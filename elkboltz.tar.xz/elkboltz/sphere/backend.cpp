//    BoltzTraP2-ELK: Backend for ELK FP-LAPW integration
//    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
//    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]

#include <cmath>
#include <algorithm>
#include <iterator>
#include <numeric>
#include <set>
#include <utility>
#include "elk_symmetry.h"  // ELK-specific symmetry headers
#include "backend.hpp"

// ELK-specific constants
const double ELK_SYMPREC = 1e-5;  // ELK's default symmetry tolerance
const int ELK_MAX_ITER = 100;      // Max iterations for ELK symmetry ops

namespace ElkCompatibility {
    /// ELK-specific symmetry operation structure
    struct ElkSymOp {
        Eigen::Matrix3d rotation;
        Eigen::Vector3d translation;
        bool time_reversal;
    };

    /// Convert ELK's symmetry format to BoltzTraP2's internal format
    std::vector<ElkSymOp> convert_elk_symmetries(const elk_symmetry_t* elk_sym) {
        std::vector<ElkSymOp> ops;
        ops.reserve(elk_sym->n_operations);
        
        for(int i = 0; i < elk_sym->n_operations; ++i) {
            ElkSymOp op;
            // ELK stores rotations in row-major order
            op.rotation = Eigen::Map<const Eigen::Matrix3d>(
                elk_sym->rotations[i], 3, 3).transpose();
            op.translation = Eigen::Map<const Eigen::Vector3d>(
                elk_sym->translations[i]);
            op.time_reversal = elk_sym->time_reversals[i];
            ops.push_back(op);
        }
        return ops;
    }

    /// ELK-specific symmetry analyzer
    class ElkSymmetryAnalyzer : public Symmetry_analyzer {
    public:
        ElkSymmetryAnalyzer(double lattvec[3][3], 
                          double positions[][3],
                          const int types[], 
                          int natoms,
                          double* magmom, 
                          Magmom_type mtype,
                          double symprec = ELK_SYMPREC) 
        {
            // Use ELK's symmetry detection instead of Spglib
            elk_symmetry_t* elk_sym = elk_get_symmetry(
                lattvec, positions, types, natoms, symprec);
            
            if(!elk_sym) {
                throw Sphere_exception("ELK symmetry detection failed");
            }

            // Process ELK's symmetry operations
            auto elk_ops = convert_elk_symmetries(elk_sym);
            process_elk_operations(elk_ops, lattvec, positions, 
                                 types, natoms, magmom, mtype, symprec);
            
            elk_free_symmetry(elk_sym);
        }

    private:
        void process_elk_operations(const std::vector<ElkSymOp>& ops,
                                   double lattvec[3][3],
                                   double positions[][3],
                                   const int types[],
                                   int natoms,
                                   double* magmom,
                                   Magmom_type mtype,
                                   double symprec) 
        {
            Eigen::Map<Eigen::Matrix3d> tlattvec(&(lattvec[0][0]));
            Eigen::PartialPivLU<Eigen::Matrix3d> solver(tlattvec);
            
            // Find atomic permutations for each operation
            Eigen::Map<Eigen::MatrixXd> direct(&(positions[0][0]), 3, natoms);
            std::set<Eigen::Matrix3i> unique_rotations;
            
            for(const auto& op : ops) {
                // Transform positions according to symmetry
                Eigen::MatrixXd transformed = op.rotation * direct;
                for(int i = 0; i < natoms; ++i) {
                    transformed.col(i) += op.translation;
                }
                
                // Find permutation
                auto perm = find_permutation(direct, transformed, symprec);
                
                // Check magnetic compatibility
                auto compat = determine_compatibility(
                    op.rotation, perm, magmom, mtype, symprec);
                
                // Store unique rotations
                Eigen::Matrix3i rot_int = (op.rotation * tlattvec).cast<int>();
                if(compat.forward) {
                    unique_rotations.insert(rot_int);
                }
                if(compat.backward) {
                    unique_rotations.insert(-rot_int);
                }
            }
            
            // Store final rotations
            this->rotations.assign(unique_rotations.begin(), 
                                 unique_rotations.end());
            
            // Compute Cartesian rotations
            for(const auto& rot : this->rotations) {
                Eigen::Matrix3d crot = solver.solve(
                    rot.cast<double>().transpose() * tlattvec).transpose();
                this->crotations.push_back(crot);
            }
        }
    };

    /// ELK-specific equivalence builder
    class ElkEquivalenceBuilder : public Sphere_equivalence_builder {
    public:
        ElkEquivalenceBuilder(double lattvec[3][3],
                            double positions[][3],
                            const int types[],
                            int natoms,
                            double* magmom,
                            Magmom_type mtype,
                            double r,
                            const int bounds[3],
                            double symprec = ELK_SYMPREC)
            : Sphere_equivalence_builder(
                lattvec, positions, types, natoms, magmom, 
                mtype, r, bounds, symprec)
        {
            // ELK-specific initialization if needed
        }
        
    protected:
        void create_grid(double lattvec[3][3], double r, const int bounds[3]) {
            // ELK-specific grid generation with potential optimizations
            double r2 = r * r;
            Lattice_tape tape(lattvec);
            
            // More efficient grid generation for ELK's typical cases
            for(int i = 0; i <= bounds[0]; ++i) {
                for(int j = (i==0 ? 0 : -bounds[1]); j <= bounds[1]; ++j) {
                    for(int k = (i==0 && j==0 ? 0 : -bounds[2]); k <= bounds[2]; ++k) {
                        Eigen::Vector3i point(i, j, k);
                        double n2 = tape.measure(point);
                        if(n2 < r2) {
                            this->grid.push_back(std::make_pair(point, n2));
                            // Add symmetric equivalents if not (0,0,0)
                            if(i != 0 || j != 0 || k != 0) {
                                this->grid.push_back(std::make_pair(-point, n2));
                            }
                        }
                    }
                }
            }
            
            std::sort(this->grid.begin(), this->grid.end(),
                     compare_second<point_with_sqnorm>);
        }
    };
}

// Factory functions for ELK integration
extern "C" {
    Symmetry_analyzer* create_elk_symmetry_analyzer(
        double lattvec[3][3],
        double positions[][3],
        const int types[],
        int natoms,
        double* magmom,
        Magmom_type mtype,
        double symprec) 
    {
        return new ElkCompatibility::ElkSymmetryAnalyzer(
            lattvec, positions, types, natoms, magmom, mtype, symprec);
    }
    
    Sphere_equivalence_builder* create_elk_equivalence_builder(
        double lattvec[3][3],
        double positions[][3],
        const int types[],
        int natoms,
        double* magmom,
        Magmom_type mtype,
        double r,
        const int bounds[3],
        double symprec) 
    {
        return new ElkCompatibility::ElkEquivalenceBuilder(
            lattvec, positions, types, natoms, magmom, 
            mtype, r, bounds, symprec);
    }
}
