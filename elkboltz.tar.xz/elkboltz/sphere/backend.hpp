//    BoltzTraP2-ELK: Backend header for ELK FP-LAPW integration
//    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
//    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]

#pragma once

#include <stdexcept>
#include <string>
#include <vector>
#include <utility>
#include <Eigen/Dense>

// ELK-specific headers
extern "C" {
#include "elk_symmetry.h"  // ELK's symmetry detection headers
}

/// Exception class for ELK-specific errors
class ELK_exception : public std::runtime_error {
public:
    ELK_exception(const std::string& message) 
        : std::runtime_error("[ELK] " + message) {}
};

/// Enhanced magnetic moment type for ELK
enum ELKMagmom_type {
    unpolarized = 0,     // No magnetization
    collinear = 1,       // Collinear magnetization (1 value per atom)
    noncollinear = 2,    // Non-collinear magnetization (3 values per atom)
    spin_spiral = 3      // ELK-specific spin spiral configuration
};

/// ELK-specific symmetry operation data
struct ELKSymOp {
    Eigen::Matrix3d rotation;
    Eigen::Vector3d translation;
    bool time_reversal;
    int spacegroup_op_index;
};

/// Base class for ELK symmetry analysis
class ELKSymmetryAnalyzer {
public:
    ELKSymmetryAnalyzer(double lattvec[3][3], 
                       double positions[][3],
                       const int types[], 
                       int natoms,
                       double* magmom, 
                       ELKMagmom_type mtype,
                       double symprec = 1e-5);
    
    virtual ~ELKSymmetryAnalyzer() = default;
    
    int get_nrotations() const {
        return static_cast<int>(rotations.size());
    }
    
    const std::vector<ELKSymOp>& get_symmetry_operations() const {
        return symmetry_ops;
    }
    
protected:
    std::vector<Eigen::Matrix3i> rotations;
    std::vector<Eigen::Matrix3d> crotations;
    std::vector<ELKSymOp> symmetry_ops;
    
    void analyze_elk_symmetries(double lattvec[3][3],
                               double positions[][3],
                               const int types[],
                               int natoms,
                               double* magmom,
                               ELKMagmom_type mtype,
                               double symprec);
};

/// ELK-specific equivalence builder
class ELKEquivalenceBuilder : public ELKSymmetryAnalyzer {
public:
    ELKEquivalenceBuilder(double lattvec[3][3],
                         double positions[][3],
                         const int types[],
                         int natoms,
                         double* magmom,
                         ELKMagmom_type mtype,
                         double r,
                         const int bounds[3],
                         double symprec = 1e-5);
    
    const std::vector<point_with_sqnorm>& get_grid() const {
        return grid;
    }
    
    const std::vector<int>& get_mapping() const {
        return mapping;
    }
    
    void get_point(int index, int point[3]) const {
        Eigen::Map<Eigen::Vector3i> wrapper(point);
        wrapper = grid[index].first;
    }

protected:
    std::vector<point_with_sqnorm> grid;
    std::vector<int> mapping;
    
    void create_elk_grid(double lattvec[3][3], 
                        double r,
                        const int bounds[3]);
};

/// ELK-specific degeneracy counter
class ELKDegeneracyCounter : public ELKSymmetryAnalyzer {
public:
    ELKDegeneracyCounter(double lattvec[3][3],
                        double positions[][3],
                        const int types[],
                        int natoms,
                        double* magmom,
                        ELKMagmom_type mtype,
                        double symprec = 1e-5);
    
    int count_degeneracy(double point[3]);
    
    void get_point(int index, double point[3]) const {
        for(int i = 0; i < 3; ++i) {
            point[i] = kpoints[index][i];
        }
    }

private:
    double tolerance;
    std::vector<Eigen::Matrix3d> krotations;
    std::vector<Eigen::Vector3d> kpoints;
    
    void compute_reciprocal_rotations(double lattvec[3][3]);
};

// Factory functions for C interface
extern "C" {
    ELKSymmetryAnalyzer* create_elk_symmetry_analyzer(
        double lattvec[3][3],
        double positions[][3],
        const int types[],
        int natoms,
        double* magmom,
        ELKMagmom_type mtype,
        double symprec);
    
    ELKEquivalenceBuilder* create_elk_equivalence_builder(
        double lattvec[3][3],
        double positions[][3],
        const int types[],
        int natoms,
        double* magmom,
        ELKMagmom_type mtype,
        double r,
        const int bounds[3],
        double symprec);
    
    ELKDegeneracyCounter* create_elk_degeneracy_counter(
        double lattvec[3][3],
        double positions[][3],
        const int types[],
        int natoms,
        double* magmom,
        ELKMagmom_type mtype,
        double symprec);
}
