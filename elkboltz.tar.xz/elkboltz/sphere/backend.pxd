#    BoltzTraP2-ELK: Cython definitions for ELK FP-LAPW backend
#    Original BoltzTraP2 Copyright (C) 2017-2025 (see original header)
#    ELK-specific modifications Copyright (C) [YEAR] [YOUR INSTITUTION]

from libcpp cimport bool
from libcpp.vector cimport vector
from libcpp.string cimport string

cdef extern from "elk_symmetry.h":
    ctypedef struct elk_symmetry_operation_t:
        double rotation[3][3]
        double translation[3]
        bool time_reversal
        int spacegroup_number
        int operation_index

    ctypedef struct elk_symmetry_t:
        int n_operations
        elk_symmetry_operation_t* operations
        double lattice[3][3]
        double* positions
        int* types
        int natoms
        double symprec
        char international_symbol[16]

    elk_symmetry_t* elk_get_symmetry(double[3][3],
                                   double[][3],
                                   const int[],
                                   int,
                                   double) nogil except +
    void elk_free_symmetry(elk_symmetry_t*) nogil

cdef extern from "elk_backend.hpp":
    cpdef enum ELKMagmom_type:
        unpolarized,
        collinear,
        noncollinear,
        spin_spiral  # ELK-specific magnetic type
    
    cdef cppclass ELKSymmetryAnalyzer:
        ELKSymmetryAnalyzer(double[3][3],
                          double[][3],
                          int[],
                          int,
                          double*,
                          ELKMagmom_type,
                          double) except +
        int get_nrotations()
        const vector[elk_symmetry_operation_t]& get_symmetry_operations()
        int get_ntensors()
        void get_tensor(int, double[9])
    
    cdef cppclass ELKEquivalenceBuilder(ELKSymmetryAnalyzer):
        ELKEquivalenceBuilder(double[3][3],
                            double[][3],
                            int[],
                            int,
                            double*,
                            ELKMagmom_type,
                            double,
                            int[3],
                            double) except +
        vector[int] get_mapping()
        void get_point(int, int[3])
        const vector[pair[vector[int], double]]& get_grid()
    
    cdef cppclass ELKDegeneracyCounter(ELKSymmetryAnalyzer):
        ELKDegeneracyCounter(double[3][3],
                           double[][3],
                           int[],
                           int,
                           double*,
                           ELKMagmom_type,
                           double) except +
        vector[int] get_mapping()
        int count_degeneracy(double[3])
        void get_point(int, double[3])
        const vector[vector[double]]& get_kpoints()

# Factory functions for Python interface
cdef extern from "elk_interface.h":
    ELKSymmetryAnalyzer* create_elk_symmetry_analyzer(
        double[3][3],
        double[][3],
        int[],
        int,
        double*,
        ELKMagmom_type,
        double) except +
    
    ELKEquivalenceBuilder* create_elk_equivalence_builder(
        double[3][3],
        double[][3],
        int[],
        int,
        double*,
        ELKMagmom_type,
        double,
        int[3],
        double) except +
    
    ELKDegeneracyCounter* create_elk_degeneracy_counter(
        double[3][3],
        double[][3],
        int[],
        int,
        double*,
        ELKMagmom_type,
        double) except +
