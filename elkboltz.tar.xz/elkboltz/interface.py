#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# ELK Transport Properties Calculator
# Interface for calculating transport properties from ELK FP-LAPW calculations
#

import argparse
import os
import sys
import logging
import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple, Dict

# Import ELK-specific modules
import elkio
import transport
import interpolation
import visualization

# Constants
HA_TO_EV = 27.2114
BOHR_TO_ANGSTROM = 0.529177

def setup_logging(verbose: int) -> None:
    """Configure logging level based on verbosity."""
    levels = [logging.ERROR, logging.WARNING, logging.INFO, logging.DEBUG]
    level = levels[min(verbose, len(levels)-1)]
    logging.basicConfig(level=level, format='%(levelname)s: %(message)s')

def parse_interpolate(args: argparse.Namespace) -> None:
    """Parse arguments for band interpolation."""
    logging.info(f"Reading ELK output from {args.input_dir}")
    
    # Read ELK output
    try:
        elk_data = elkio.read_elk_output(args.input_dir)
    except Exception as e:
        logging.error(f"Failed to read ELK output: {str(e)}")
        sys.exit(1)
        
    # Check energy window
    if args.emin >= args.emax:
        logging.error("Energy window has zero or negative width")
        sys.exit(1)
        
    # Perform interpolation
    logging.info("Starting band interpolation...")
    try:
        coeffs, kpoints = interpolation.interpolate_bands(
            elk_data, 
            nkpoints=args.nkpoints,
            emin=args.emin,
            emax=args.emax,
            degree=args.poly_degree
        )
    except Exception as e:
        logging.error(f"Interpolation failed: {str(e)}")
        sys.exit(1)
        
    # Save results
    elkio.save_interpolation(args.output, coeffs, kpoints, elk_data)
    logging.info(f"Interpolation saved to {args.output}")

def parse_transport(args: argparse.Namespace) -> None:
    """Parse arguments for transport calculation."""
    # Load interpolation data
    try:
        coeffs, kpoints, elk_data = elkio.load_interpolation(args.input_file)
    except Exception as e:
        logging.error(f"Failed to load interpolation data: {str(e)}")
        sys.exit(1)
        
    # Calculate transport properties
    logging.info("Calculating transport properties...")
    try:
        results = transport.calculate_transport(
            coeffs, 
            kpoints, 
            elk_data,
            temperatures=args.temperatures,
            doping_levels=args.doping,
            scattering_model=args.scattering
        )
    except Exception as e:
        logging.error(f"Transport calculation failed: {str(e)}")
        sys.exit(1)
        
    # Save results
    output_base = os.path.splitext(args.input_file)[0]
    elkio.save_transport_results(output_base, results)
    logging.info(f"Results saved to {output_base}.*")

def parse_plot(args: argparse.Namespace) -> None:
    """Parse arguments for plotting."""
    # Load results
    try:
        results = elkio.load_transport_results(args.input_file)
    except Exception as e:
        logging.error(f"Failed to load results: {str(e)}")
        sys.exit(1)
        
    # Generate plots
    visualization.plot_transport_properties(results, args.property, args.output)
    logging.info(f"Plot saved to {args.output}")

def parse_bandstructure(args: argparse.Namespace) -> None:
    """Parse arguments for band structure plotting."""
    # Load data
    try:
        if args.input_file.endswith('.elk'):
            elk_data = elkio.read_elk_output(args.input_file)
            kpath, bands = elkio.extract_bandstructure(elk_data)
        else:
            coeffs, kpoints, elk_data = elkio.load_interpolation(args.input_file)
            kpath, bands = interpolation.calculate_bandstructure(
                coeffs, kpoints, elk_data, args.kpath, args.nkpoints
            )
    except Exception as e:
        logging.error(f"Failed to load data: {str(e)}")
        sys.exit(1)
        
    # Plot
    visualization.plot_bandstructure(kpath, bands, args.output)
    logging.info(f"Band structure plot saved to {args.output}")

def main():
    """Main entry point for the ELK transport calculator."""
    parser = argparse.ArgumentParser(
        description="ELK Transport Properties Calculator",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    
    # Global arguments
    parser.add_argument('-v', '--verbose', action='count', default=0,
                       help='increase verbosity level')
    
    # Subcommands
    subparsers = parser.add_subparsers(title='subcommands', dest='command')
    subparsers.required = True
    
    # Interpolate subcommand
    interp_parser = subparsers.add_parser('interpolate',
        help='interpolate ELK band structure')
    interp_parser.add_argument('input_dir',
        help='directory containing ELK output files')
    interp_parser.add_argument('-o', '--output', default='interpolated.elk',
        help='output file for interpolation data')
    interp_parser.add_argument('-n', '--nkpoints', type=int, default=1000,
        help='number of k-points for interpolation')
    interp_parser.add_argument('-e', '--emin', type=float, default=-1.0,
        help='minimum energy for interpolation (eV)')
    interp_parser.add_argument('-E', '--emax', type=float, default=1.0,
        help='maximum energy for interpolation (eV)')
    interp_parser.add_argument('-d', '--poly-degree', type=int, default=8,
        help='polynomial degree for interpolation')
    interp_parser.set_defaults(func=parse_interpolate)
    
    # Transport subcommand
    transport_parser = subparsers.add_parser('transport',
        help='calculate transport properties')
    transport_parser.add_argument('input_file',
        help='interpolated data file or ELK output')
    transport_parser.add_argument('-T', '--temperatures', nargs='+', 
        type=float, default=[300], help='temperatures in K')
    transport_parser.add_argument('-D', '--doping', nargs='+', 
        type=float, help='doping levels in cm^-3')
    transport_parser.add_argument('-s', '--scattering', 
        choices=['constant', 'energy-dependent'], default='constant',
        help='scattering model to use')
    transport_parser.set_defaults(func=parse_transport)
    
    # Plot subcommand
    plot_parser = subparsers.add_parser('plot',
        help='plot transport properties')
    plot_parser.add_argument('input_file',
        help='file with transport results')
    plot_parser.add_argument('property',
        choices=['conductivity', 'seebeck', 'kappa', 'pf', 'dos'],
        help='property to plot')
    plot_parser.add_argument('-o', '--output',
        help='output file for plot')
    plot_parser.set_defaults(func=parse_plot)
    
    # Bandstructure subcommand
    bands_parser = subparsers.add_parser('bands',
        help='plot band structure')
    bands_parser.add_argument('input_file',
        help='ELK output or interpolated data file')
    bands_parser.add_argument('-o', '--output',
        help='output file for plot')
    bands_parser.add_argument('-k', '--kpath',
        help='k-path in reciprocal space')
    bands_parser.add_argument('-n', '--nkpoints', type=int, default=100,
        help='points along each path segment')
    bands_parser.set_defaults(func=parse_bandstructure)
    
    # Parse arguments
    args = parser.parse_args()
    setup_logging(args.verbose)
    
    # Call the appropriate function
    args.func(args)

if __name__ == '__main__':
    main()
