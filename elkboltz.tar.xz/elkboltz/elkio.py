# -*- coding: utf-8 -*-
# ELK-specific file I/O operations for BoltzTraP2

import os
import numpy as np
from ase import Atoms
from ase.units import Bohr, Hartree

def load_elk_output(elk_path):
    """Load main ELK output files from calculation directory.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Dictionary containing parsed ELK data
    """
    data = {}
    
    # Read lattice and atomic positions from LATTICE.OUT and GEOMETRY.OUT
    data['atoms'] = read_elk_geometry(elk_path)
    
    # Read electronic structure data
    data.update(read_elk_electronic(elk_path))
    
    # Read additional metadata
    data.update(read_elk_metadata(elk_path))
    
    return data

def read_elk_geometry(elk_path):
    """Read lattice and atomic positions from ELK output files.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        Atoms: ASE Atoms object with crystal structure
    """
    # Read lattice vectors from LATTICE.OUT
    with open(os.path.join(elk_path, 'LATTICE.OUT'), 'r') as f:
        lines = f.readlines()
        alat = float(lines[0].split()[-1]) * Bohr  # Convert to Angstrom
        lattice = []
        for line in lines[1:4]:
            lattice.append([float(x) * alat for x in line.split()])
    
    # Read atomic positions from GEOMETRY.OUT
    with open(os.path.join(elk_path, 'GEOMETRY.OUT'), 'r') as f:
        lines = f.readlines()
        species = []
        positions = []
        for line in lines[1:]:  # Skip header
            parts = line.split()
            species.append(parts[0])
            positions.append([float(x) for x in parts[1:4]])
    
    return Atoms(symbols=species, positions=positions, cell=lattice)

def read_elk_electronic(elk_path):
    """Read electronic structure data from ELK output files.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Dictionary containing kpoints, eigenvalues, fermi energy, etc.
    """
    data = {}
    
    # Read Fermi energy from FERMI.OUT
    with open(os.path.join(elk_path, 'FERMI.OUT'), 'r') as f:
        data['fermi'] = float(f.readline().strip()) * Hartree
    
    # Read number of electrons from INFO.OUT
    with open(os.path.join(elk_path, 'INFO.OUT'), 'r') as f:
        for line in f:
            if 'total number of electrons' in line:
                data['nelect'] = float(line.split()[-1])
                break
    
    # Read band structure data from BAND.OUT or EIGVAL.OUT
    if os.path.exists(os.path.join(elk_path, 'BAND.OUT')):
        data.update(read_elk_bandstructure(elk_path))
    else:
        data.update(read_elk_eigenvalues(elk_path))
    
    # Read momentum matrix elements if available
    if os.path.exists(os.path.join(elk_path, 'PMAT.OUT')):
        data['pmatrix'] = read_elk_pmatrix(elk_path)
    
    return data

def read_elk_eigenvalues(elk_path):
    """Read eigenvalues from EIGVAL.OUT file.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Dictionary containing kpoints and eigenvalues
    """
    with open(os.path.join(elk_path, 'EIGVAL.OUT'), 'r') as f:
        lines = f.readlines()
        
    # First line contains nkpts, nstsv, nspinor
    header = lines[0].split()
    nkpts = int(header[0])
    nbands = int(header[1])
    
    kpoints = []
    eigenvalues = []
    
    for ik in range(nkpts):
        # Each k-point section starts with k-point coordinates
        kline = lines[1 + ik*(nbands+1)].split()
        kpoints.append([float(x) for x in kline[:3]])
        
        # Following lines contain eigenvalues for this k-point
        eigvals = []
        for ib in range(nbands):
            eigline = lines[2 + ik*(nbands+1) + ib].split()
            eigvals.append(float(eigline[1]) * Hartree)  # Convert to Ha
        eigenvalues.append(eigvals)
    
    return {
        'kpoints': np.array(kpoints),
        'eigenvalues': np.array(eigenvalues).T  # Transpose to match BoltzTraP2 format
    }

def read_elk_pmatrix(elk_path):
    """Read momentum matrix elements from PMAT.OUT file.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        ndarray: Momentum matrix elements in BoltzTraP2 format
    """
    # Implementation depends on ELK version
    # This is a placeholder - actual implementation needs to handle ELK's format
    return None

def read_elk_metadata(elk_path):
    """Read metadata from ELK output files.
    
    Args:
        elk_path: Path to ELK output directory
        
    Returns:
        dict: Dictionary containing ELK version and parameters
    """
    metadata = {}
    
    # Try to get version from INFO.OUT
    with open(os.path.join(elk_path, 'INFO.OUT'), 'r') as f:
        for line in f:
            if 'ELK version' in line:
                metadata['version'] = line.split()[-1]
                break
    
    # Read input parameters from INPUT.OUT
    metadata['parameters'] = {}
    if os.path.exists(os.path.join(elk_path, 'INPUT.OUT')):
        with open(os.path.join(elk_path, 'INPUT.OUT'), 'r') as f:
            for line in f:
                if ':' in line:
                    key, value = line.split(':', 1)
                    metadata['parameters'][key.strip()] = value.strip()
    
    return metadata
