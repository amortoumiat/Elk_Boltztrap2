# Example usage with Elk data
results = elk_calc_transport(
    elk_bandfile="BAND.OUT",
    N0=8,  # Number of valence electrons
    Tr=np.linspace(100, 1000, 10),  # Temperature range
    vuc=100.0,  # Unit cell volume in Bohr^3
    nspin=1,  # Non-spin-polarized calculation
    scattering_model="uniform_tau"
)

# Access results:
print("Seebeck coefficients at 300K:", results['seebeck'][300])
