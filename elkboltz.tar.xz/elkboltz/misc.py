# -*- coding: utf-8 -*-
#    BoltzTraP2-ELK: Miscellaneous utilities for ELK FP-LAPW integration
#    Copyright (C) 2017-2025 Original BoltzTraP2 authors (see original header)
#    Copyright (C) [YEAR] [YOUR INSTITUTION] - ELK-specific modifications
#
#    This file is part of BoltzTraP2-ELK.
#
#    BoltzTraP2-ELK is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

import contextlib
import io
import logging
import os
import os.path
import sys
import time
import re
from ase.units import Hartree, Bohr

# ELK-specific logger
elk_logger = logging.getLogger("BoltzTraP2.ELK")

def ffloat_elk(arg):
    """Enhanced Fortran float parser with ELK-specific number formats."""
    try:
        # Handle ELK's scientific notation (may use 'D' or 'E')
        num = arg.lower().replace("d", "e")
        # Remove any non-numeric characters that might appear in ELK output
        num = re.sub(r'[^0-9eE.+-]', '', num)
        return float(num)
    except ValueError as e:
        elk_logger.error(f"Could not parse ELK number: {arg}")
        raise ValueError(f"Invalid ELK number format: {arg}") from e

def elk_info(*args):
    """Print ELK-specific information with proper logging."""
    with io.StringIO("") as message:
        print("[ELK] ", *args, file=message)
        for line in message.getvalue().splitlines():
            elk_logger.info(line)

def elk_warning(*args):
    """Print ELK-specific warnings with proper logging."""
    with io.StringIO("") as message:
        print("[ELK WARNING] ", *args, file=message)
        for line in message.getvalue().splitlines():
            elk_logger.warning(line)

def elk_exit(message, code=1):
    """ELK-specific error exit with logging."""
    elk_logger.error(f"ELK FATAL: {message}")
    sys.exit(code)

@contextlib.contextmanager
def elk_dir_context(dirname):
    """Enhanced directory context manager for ELK's directory structure."""
    cwd = os.getcwd()
    try:
        if not os.path.isdir(dirname):
            raise FileNotFoundError(f"ELK directory not found: {dirname}")
        os.chdir(dirname)
        elk_info(f"Working in ELK directory: {os.getcwd()}")
        yield
    except Exception as e:
        elk_logger.error(f"Error in ELK directory context: {str(e)}")
        raise
    finally:
        os.chdir(cwd)
        elk_info(f"Returned to original directory: {cwd}")

class ELKTimer(TimerContext):
    """Extended timer with ELK-specific performance logging."""
    
    def __enter__(self):
        """Start timer and log initialization."""
        elk_info("Starting ELK operation timer")
        return super().__enter__()
    
    def get_deltat(self):
        """Get elapsed time with ELK logging."""
        dt = super().get_deltat()
        elk_info(f"Operation completed in {dt:.3f} seconds")
        return dt

def convert_elk_units(value, from_unit, to_unit='hartree'):
    """Convert ELK units to target units.
    
    Args:
        value: Value to convert
        from_unit: Source unit ('hartree', 'ev', 'bohr', 'angstrom')
        to_unit: Target unit
        
    Returns:
        Converted value
    """
    units = {
        'hartree': Hartree,
        'ev': 1.0,
        'bohr': Bohr,
        'angstrom': 1.0
    }
    
    if from_unit not in units or to_unit not in units:
        elk_warning(f"Unsupported unit conversion: {from_unit} to {to_unit}")
        return value
    
    if from_unit == to_unit:
        return value
    
    # Convert to atomic units first if needed
    if from_unit == 'ev':
        value /= Hartree
    elif from_unit == 'angstrom':
        value /= Bohr
    
    # Convert to target units
    if to_unit == 'ev':
        value *= Hartree
    elif to_unit == 'angstrom':
        value *= Bohr
    
    return value

def validate_elk_file(filename, required_contents=None):
    """Validate an ELK output file exists and optionally check contents.
    
    Args:
        filename: Name of ELK file to check
        required_contents: List of strings that must appear in file
        
    Returns:
        bool: True if file is valid
    """
    if not os.path.isfile(filename):
        elk_warning(f"ELK file not found: {filename}")
        return False
    
    if required_contents:
        try:
            with open(filename, 'r') as f:
                content = f.read()
                for pattern in required_contents:
                    if pattern not in content:
                        elk_warning(f"Required pattern '{pattern}' not found in {filename}")
                        return False
        except IOError as e:
            elk_warning(f"Could not read ELK file {filename}: {str(e)}")
            return False
    
    return True

# Keep original BoltzTraP2 utilities for compatibility
info = logging.info
warning = logging.warning
lexit = sys.exit
dir_context = contextlib.contextmanager(os.chdir)
TimerContext = ELKTimer  # Use our enhanced timer by default
