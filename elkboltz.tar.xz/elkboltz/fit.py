# elk_bt2_adapter.py
import numpy as np
from BoltzTraP2 import dft as bt_dft

def read_elk_bands(elk_path="."):
    """Read ELK output files and prepare data for BoltzTraP2"""
    
    # Read lattice vectors from LATTICE.OUT
    with open(elk_path + "/LATTICE.OUT", "r") as f:
        lines = f.readlines()
    lattvec = np.array([list(map(float, line.split()[1:4])) 
                      for line in lines[1:4]])
    
    # Read k-points from KPOINTS.OUT
    kpoints = np.loadtxt(elk_path + "/KPOINTS.OUT")[:, 1:4]
    
    # Read eigenvalues from EIGVAL.OUT
    with open(elk_path + "/EIGVAL.OUT", "r") as f:
        lines = f.readlines()
    
    # Find number of bands and k-points
    nkpts = int(lines[0].split()[3])
    nbands = int(lines[0].split()[4])
    
    # Read eigenvalues (in Hartree, convert to eV)
    ebands = np.zeros((nkpts, nbands))
    for ik in range(nkpts):
        for ib in range(nbands):
            line = lines[1 + ik*(nbands+1) + ib]
            ebands[ik, ib] = float(line.split()[1]) * 27.2114  # Hartree to eV
    
    # Try to read momentum matrix elements if available
    pmat = None
    try:
        with open(elk_path + "/PMAT.OUT", "r") as f:
            pmat_data = np.loadtxt(f)
        pmat = np.zeros((nkpts, nbands, nbands, 3))
        # Process PMAT.OUT format (needs adjustment based on your ELK version)
        # ...
    except FileNotFoundError:
        print("Warning: No PMAT.OUT found - velocity calculations may be less accurate")
    
    # Create BoltzTraP2 dataset
    data = bt_dft.DFTData(
        kpoints=kpoints,
        eb=ebands,
        mommat=pmat,
        lattvec=lattvec,
        nelect=None,  # You may need to set this from ELK's INFO.OUT
        dosweight=None,
        atype=None,
        apos=None,
        volume=None
    )
    
    return data

def elk_to_bt2(elk_path=".", output_file="elk_bt2.h5"):
    """Convert ELK output to BoltzTraP2 HDF5 format"""
    data = read_elk_bands(elk_path)
    bt_dft.save(data, output_file)
    return output_file
