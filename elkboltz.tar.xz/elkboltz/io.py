# -*- coding: utf-8 -*-
# ELK FP-LAPW IO Module for Transport Calculations
# Handles reading ELK output and writing transport results

import os
import glob
import logging
import numpy as np
import scipy as sp
import scipy.constants
import netCDF4 as nc
from typing import Dict, Tuple, Optional

import ase
import ase.io
from ase.units import Bohr, Ha, eV, Angstrom

# Constants
MU0 = 4 * np.pi * 1e-7  # Magnetic constant (N/A^2)
MUB = 9.274009994e-24  # Bohr magneton (J/T)
AVOGADRO = 6.02214076e23  # Avogadro's number

def read_elk_output(directory: str) -> Dict:
    """Read ELK output files from a directory.
    
    Args:
        directory: Path to directory containing ELK output
        
    Returns:
        Dictionary containing:
        - atoms: ASE Atoms object
        - fermi: Fermi level in Ha
        - kpoints: Array of k-points (nk, 3)
        - ebands: Band energies (nspin, nk, nbands)
        - nelect: Number of electrons
        - magmom: Magnetic moments (optional)
    """
    # Find main output file
    outfile = find_elk_output(directory)
    if outfile is None:
        raise FileNotFoundError("No ELK output file found in directory")
    
    # Read basic information from output
    with open(outfile, 'r') as f:
        elk_data = parse_elk_output(f.readlines())
    
    # Read band structure from BAND.OUT or BANDS.OUT
    bandfile = os.path.join(directory, "BAND.OUT")
    if not os.path.exists(bandfile):
        bandfile = os.path.join(directory, "BANDS.OUT")
    
    if not os.path.exists(bandfile):
        raise FileNotFoundError("No band structure file found")
    
    kpoints, ebands = parse_elk_bands(bandfile)
    
    # Read structure from GEOMETRY.OUT
    geomfile = os.path.join(directory, "GEOMETRY.OUT")
    if not os.path.exists(geomfile):
        raise FileNotFoundError("No geometry file found")
    
    atoms = parse_elk_geometry(geomfile)
    
    # Read magnetic moments if available
    magmom = None
    magfile = os.path.join(directory, "MOMENT.OUT")
    if os.path.exists(magfile):
        magmom = parse_elk_moments(magfile, len(atoms))
    
    return {
        'atoms': atoms,
        'fermi': elk_data['fermi'] * eV / Ha,  # Convert to Ha
        'kpoints': kpoints,
        'ebands': ebands,
        'nelect': elk_data['nelect'],
        'magmom': magmom
    }

def find_elk_output(directory: str) -> Optional[str]:
    """Find the main ELK output file in a directory."""
    candidates = glob.glob(os.path.join(directory, "*.OUT"))
    for f in candidates:
        if os.path.basename(f).upper() in ["INFO.OUT", "ELK.OUT"]:
            return f
    return None

def parse_elk_output(lines: list) -> Dict:
    """Parse ELK output file to extract key parameters."""
    data = {
        'fermi': 0.0,
        'nelect': 0,
        'spin_pol': False
    }
    
    for line in lines:
        if "Fermi energy" in line and "Ha" in line:
            data['fermi'] = float(line.split()[3])
        elif "total number of electrons" in line:
            data['nelect'] = float(line.split()[-1])
        elif "spin-polarized calculation" in line:
            data['spin_pol'] = True
    
    return data

def parse_elk_geometry(filename: str) -> ase.Atoms:
    """Parse ELK geometry file."""
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    # Lattice vectors (in Bohr)
    cell = []
    for i in range(3,6):
        cell.append([float(x) for x in lines[i].split()])
    cell = np.array(cell) * Bohr / Angstrom  # Convert to Angstrom
    
    # Atomic positions
    natoms = int(lines[6].split()[0])
    symbols = []
    positions = []
    for i in range(natoms):
        fields = lines[7+i].split()
        symbols.append(fields[0])
        positions.append([float(x) for x in fields[1:4]])
    
    return ase.Atoms(
        symbols, 
        positions=np.array(positions), 
        cell=cell, 
        pbc=True
    )

def parse_elk_bands(filename: str) -> Tuple[np.ndarray, np.ndarray]:
    """Parse ELK band structure file."""
    data = np.loadtxt(filename)
    
    # First column is k-point index, then kx, ky, kz, then bands
    kpoints = data[:, 1:4]
    ebands = data[:, 4:].T  # Transpose to (nbands, nkpoints)
    
    # For spin-polarized, would need to handle differently
    return kpoints, ebands[np.newaxis, :, :]  # Add spin dimension

def parse_elk_moments(filename: str, natoms: int) -> np.ndarray:
    """Parse ELK magnetic moments file."""
    data = np.loadtxt(filename)
    if data.ndim == 1:
        return data[:natoms]  # Collinear case
    else:
        return data[:natoms, :]  # Non-collinear case

def save_elk_transport(
    filename: str,
    data: Dict,
    Tr: np.ndarray,
    mur: np.ndarray,
    N: np.ndarray,
    cond: np.ndarray,
    seebeck: np.ndarray,
    kappa: np.ndarray,
    hall: Optional[np.ndarray] = None,
    scattering_model: str = "uniform_tau"
) -> None:
    """Save transport results in ELK-compatible format.
    
    Args:
        filename: Base filename for output
        data: Dictionary containing original system data
        Tr: Array of temperatures (nT,)
        mur: Array of chemical potentials (nT, nmu)
        N: Array of electron counts (nT, nmu)
        cond: Conductivity tensor (nT, nmu, 3, 3)
        seebeck: Seebeck tensor (nT, nmu, 3, 3)
        kappa: Electronic thermal conductivity (nT, nmu, 3, 3)
        hall: Hall tensor (nT, nmu, 3, 3, 3) [optional]
        scattering_model: Scattering model used
    """
    # Save scalar trace quantities
    save_elk_trace(
        filename + ".trace",
        data, Tr, mur, N, cond, seebeck, kappa, hall, scattering_model
    )
    
    # Save full tensors
    save_elk_tensors(
        filename + ".tensors",
        data, Tr, mur, N, cond, seebeck, kappa, hall, scattering_model
    )

def save_elk_trace(
    filename: str,
    data: Dict,
    Tr: np.ndarray,
    mur: np.ndarray,
    N: np.ndarray,
    cond: np.ndarray,
    seebeck: np.ndarray,
    kappa: np.ndarray,
    hall: Optional[np.ndarray],
    scattering_model: str
) -> None:
    """Save scalar transport properties."""
    nmu = mur.shape[-1]
    nformulas = len(data['atoms'].get_chemical_symbols()) / len(
        set(data['atoms'].get_chemical_symbols())
    )
    
    # Determine units based on scattering model
    if scattering_model == "uniform_lambda":
        cond_unit = "1/(ohm*m^2)"
        kappa_unit = "W/(m^2*K)"
        cond_factor = 1.0 / (sp.constants.alpha * sp.constants.c)
    else:  # uniform_tau
        cond_unit = "1/(ohm*m*s)"
        kappa_unit = "W/(m*K*s)"
        cond_factor = 1.0
    
    header = (
        "#{:>9s} {:>9s} {:>12s} {:>12s} {:>12s} {:>12s} {:>12s} {:>12s} {:>12s}"
        .format(
            "Ef[Ha]", "T[K]", "N[e/uc]", "DOS[1/Ha]", 
            f"S[V/K]", f"sigma/{cond_unit}", 
            "RH[m^3/C]", f"kappa/{kappa_unit}", 
            "cv[J/molK]"
        )
    )
    
    with open(filename, 'w') as f:
        f.write(header + "\n")
        for imu in range(nmu):
            for iT, T in enumerate(Tr):
                mu = mur[iT, imu]
                cv = ...  # Calculate heat capacity if available
                
                # Calculate trace values
                S_trace = seebeck[iT, imu].trace() / 3.0
                cond_trace = cond[iT, imu].trace() * cond_factor / 3.0
                kappa_trace = kappa[iT, imu].trace() * cond_factor / 3.0
                
                if hall is not None:
                    hall_trace = (
                        hall[iT, imu, 0, 1, 2] + 
                        hall[iT, imu, 1, 2, 0] + 
                        hall[iT, imu, 2, 0, 1]
                    ) / 3.0
                else:
                    hall_trace = 0.0
                
                line = (
                    f"{mu:10.6f} {T:9.2f} "
                    f"{(N[iT, imu] + data['nelect']):12.6f} "
                    f"{0.0:12.6f} "  # Placeholder for DOS
                    f"{S_trace:12.6f} {cond_trace:12.6e} "
                    f"{hall_trace:12.6e} {kappa_trace:12.6e} "
                    f"{cv:12.6f}"  # Placeholder for heat capacity
                )
                f.write(line + "\n")

def save_elk_tensors(
    filename: str,
    data: Dict,
    Tr: np.ndarray,
    mur: np.ndarray,
    N: np.ndarray,
    cond: np.ndarray,
    seebeck: np.ndarray,
    kappa: np.ndarray,
    hall: Optional[np.ndarray],
    scattering_model: str
) -> None:
    """Save full transport tensors."""
    # Similar implementation to save_elk_trace but with full tensors
    pass
